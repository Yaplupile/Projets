open Graphics;;
open Uf;;


print_string "Donnez les dimensions du labyrinthe :" ;; (* Ici nous demandons les dimensions du labyrinthe et nous créeons nos variables globales*)
print_newline();;
print_string "Largeur = ";;
let l = int_of_string(read_line());;
print_string "Hauteur = ";;
let h = int_of_string(read_line());;
print_string "Taille des cases = ";;
let taille_case = int_of_string(read_line());;

let end_game = ref false

let case_pacman = ref 0 ;;

let case_fantome= ref (l-1);;

let mur_au_hasard l h = (* renvoie un triplet (d, x, y) *)
let n = Random.int ((l-1) * h + l * (h-1)) in
if n < (l-1) * h
then (0, n mod (l-1), n / (l-1))
else let n2 = n - (l-1) * h in
(1, n2 mod l, n2 / l);;


let cases_adjacentes l h (d,x,y)= match (d,x,y) with (* On calcule les deux cases qui entourent le mur entré en paramètre*)
|(0,_,_)->( x + y*l , x + y*l + 1)
|(_,_,_)->( x + y*l , x + (y+1)*l);;


let generate_lab l h= 
    let mur_present = [|Array.init (l-1) (fun _ ->Array.make h true); Array.init (l) (fun _ ->Array.make (h-1) true)|] in (*On crée le tableau qui représentera les murs présents en metant toutes les valeurs à True*)
    let voisine = Array.init ( l*h ) (fun _ -> [])  in (*On crée le tableau qui représente les voisins d'une case avec toutes les valeurs avec la liste vide *)
    let uf = Union_find.create (l*h) in (*On crée notre structure de données UF*)
    let i= ref 0 in
    while ( !i < ( (l * h) -1 ) ) do                                    (* Pour chaque passage dans la boucle, on prend un mur aléatoire et on donne ses cases adjacentes.*)
        let (d,x,y)=mur_au_hasard l h in
        let (a,b) = cases_adjacentes l h (d,x,y) in
        if (Union_find.find uf.tab a <> Union_find.find uf.tab b) then (*Si les cases n'ont pas le même parent alors on les fusionne et on actualise mur_présent et voisine, sinon on recommence avec un autre mur aléatoire*)
            begin
                Union_find.union uf a b ;
                voisine.(a)<-voisine.(a) @ [b];
                voisine.(b)<-voisine.(b) @ [a];
                mur_present.(d).(x).(y) <- false;
                i := !i+1;
            end;
    done;
(mur_present,voisine);; (*On renvoie mur présent et voisine*)


let trace_pourtour upleftx uplefty taille_case l h = 
begin 
let hauteur = string_of_int((h+2)*taille_case) in  (*On définit les dimensions de notre fenêtre et on la crée*)
let longueur= string_of_int((l+2)*taille_case) in
open_graph (" "^longueur^"x"^hauteur);
set_color black;
moveto upleftx uplefty ;                            (*On trace le pourtour du labyrinthe*)
lineto ( upleftx+l*taille_case) uplefty;
lineto ( upleftx+l*taille_case) (uplefty-(h-1)*taille_case);
moveto ( upleftx+l*taille_case) (uplefty-h*taille_case);
lineto upleftx (uplefty-h*taille_case);
lineto upleftx uplefty;
end;;

let trace_mur upleftx uplefty taille_case (d,x,y) = begin
let (x',y')=(upleftx + (x+1) * taille_case , uplefty - (y+1)*taille_case ) in (* On trace les murs en fonction de leur position et de leur inclinaison*)
moveto x' y';
if d=0 then
lineto x' (y' + taille_case);
if d=1 then 
lineto (x'- taille_case) y';
end;;

let trace_lab upleftx uplefty taille_case l h mur_present=
    trace_pourtour upleftx uplefty taille_case l h;
    for i=0 to l-2 do                                           (*On trace tous les murs horizontaux à l'aide de mur_présent et trace_mur*)
        for j=0 to h-1 do
            if mur_present.(0).(i).(j) = true then 
            trace_mur upleftx uplefty taille_case (0,i,j);
        done;
    done;

    for i=0 to l-1 do                                           (*On trace tous les murs verticaux à l'aide de mur_présent et de trace_mur*)
        for j=0 to h-2 do
            if mur_present.(1).(i).(j) = true then 
            trace_mur upleftx uplefty taille_case (1,i,j);
        done;
    done;
;;


let mur_milieu l h c1 c2 =                     (*Cette fonction donne le mur entre deux cases adjacentes rentrées en paramètres*)
let c=ref 0 in
if c1<c2 then begin c:=c1 end;
if c1>c2 then begin c:=c2 end;
let (d,x,y)=(ref 0,ref 0,ref 0) in
x := !c mod l;
y := !c / l;
if (c1-c2) mod l == 0 then begin d:=1 end;
if (c1-c2) mod l <> 0 then begin d:=0 end;
(!d,!x,!y);;

let trace_pacman pos oldpos l h taille_case upleftx uplefty =                           (*Cette fonction est purement esthétique et trace le pacman*)
    let x = (upleftx + taille_case/2 + taille_case*(pos mod l )) in
    let y = (uplefty - taille_case/2 - taille_case*(pos / l )) in
    let x'= (upleftx + taille_case/2 + taille_case*(oldpos mod l )) in
    let y'= (uplefty - taille_case/2 - taille_case*(oldpos / l ))in
    set_color white;
    fill_arc (x'+taille_case/20) y' (11*taille_case/27) (10*taille_case/27) 35 315;
    set_color black;
    fill_arc (x+ taille_case/20) y (11*taille_case/27) (10*taille_case/27) 35 315;
    set_color yellow;
    fill_arc x y (taille_case/3) (taille_case/3) 35 315;
    set_color black;
    fill_circle x (y+taille_case/6) (taille_case/15)
;;

let trace_fantome pos oldpos l h taille_case upleftx uplefty =                          (*De même que Trace_pacman, on trace ici le fantôme*)
    let x = (upleftx + taille_case/2 + taille_case*(pos mod l )) in
    let y = (uplefty - taille_case/2 - taille_case*(pos / l )) in
    let x'= (upleftx + taille_case/2 + taille_case*(oldpos mod l )) in
    let y'= (uplefty - taille_case/2 - taille_case*(oldpos / l ))in
    set_color white;
    fill_circle x' y' (10*taille_case/27);
    set_color black;
    fill_circle x y (10*taille_case/27);
    set_color red;
    fill_circle x y (taille_case/3);
    set_color white;
    fill_circle (x-taille_case/7) (y+taille_case/7) (taille_case/12);
    fill_circle (x+taille_case/7) (y+taille_case/7) (taille_case/12);
    set_color black;
    fill_circle (x-taille_case/8) (y+taille_case/7) (taille_case/17);
    fill_circle (x+taille_case/6) (y+taille_case/7) (taille_case/17);
    moveto (x-taille_case/7) (y-taille_case/7);
    lineto (x+taille_case/7) (y-taille_case/7)
;;

let rec est_relie depart arrive evite voisine =         (*On prend la liste de voisins d'une case et on cherche le bon chemin parmi ces voisins*)
let fin=ref false in
if depart == arrive then begin fin:=true end;
for i=0 to (List.length voisine.(depart) - 1) do        (*Pour chaque voisin on vérifie que cela n'est pas la case évite et on retrace le bon chemin en changeant la case évite*)
    if List.nth voisine.(depart) i <> evite then 
    begin
        if est_relie (List.nth voisine.(depart) i) arrive depart voisine then fin:=true
    end;
done;
!fin;;


let pacman l h c taille_case upleftx uplefty =
    

    let cha = read_key() in         (* On cherche la touche pressée*)
    
    if !end_game==false then           (*Si le jeu  est fini, cela servira à arrêter les mouvements du pacman*)
    begin
    
    if ( cha =='z') && (!case_pacman < (l-1)) then begin sound 440 500; end;           (*Effectue un son si le pacman se cogne aux murs exterieurs selon la touche pressée *)
    if ( cha =='s') && (!case_pacman > (h*(l-1))) then begin sound 440 500; end;
    if ( cha =='q') && (!case_pacman mod l == 0) then begin sound 440 500; end;
    if ( cha =='d') && (!case_pacman mod l == (l-1)) then begin sound 440 500; end;

    if ( cha =='z') && (!case_pacman > (l-1)) then                                              (*Dans la section suivante, pour chaque touche, on teste si il y a une mur dans la direction ou veut se diriger pacman.*)
    begin                                                                                          (*Si oui, alors on fait un son et on empêvhe le mouvement, sinon on bouge le pacman dans la case demandée*)
        let (d,x,y)= mur_milieu l h !case_pacman ((!case_pacman)-l) in
        if c.(d).(x).(y) == false then
            begin
            trace_pacman ((!case_pacman)-l) !case_pacman l h taille_case upleftx uplefty;
            case_pacman:=!case_pacman-l;
            end;
        if c.(d).(x).(y) == true then
            begin
            sound 440 500;
            end;
    end;

    if ( cha =='s')  &&  (!case_pacman < (l*(h-1))) then
    begin
        let (d,x,y)= mur_milieu l h !case_pacman ((!case_pacman)+l) in
        if c.(d).(x).(y)==false then
            begin
            trace_pacman ((!case_pacman)+l) !case_pacman l h taille_case upleftx uplefty;
            case_pacman:=!case_pacman+l;
            end;
        if c.(d).(x).(y) == true then
            begin
            sound 440 500;
            end;
    end;

    if ( cha =='q')  &&  (!case_pacman mod l <> 0) then
    begin
        let (d,x,y)= mur_milieu l h !case_pacman ((!case_pacman)-1) in
        if c.(d).(x).(y)==false then
            begin
            trace_pacman ((!case_pacman)-1) !case_pacman l h taille_case upleftx uplefty;
            case_pacman:=!case_pacman-1;
            end;
        if c.(d).(x).(y) == true then
            begin
            sound 440 500;
            end;
    end;

    if ( cha =='d') &&  (!case_pacman mod l <> (l-1)) then
    begin
        let (d,x,y)= mur_milieu l h !case_pacman ((!case_pacman)+1) in
        if c.(d).(x).(y)==false then
            begin
            trace_pacman ((!case_pacman)+1) !case_pacman l h taille_case upleftx uplefty;
            case_pacman:=!case_pacman+1;
            end;
        if c.(d).(x).(y) == true then
            begin
            sound 440 500;
            end;
    end;
end
let fantome voisine=                                                             (*On actualise la position du fantôme à l'aide du chemin trouvé par la fonction est_relie plus haut*)
let once = ref true in                                                             (*La variable Once permet une optimisation en évitant des calculs supplémentaires si on a déjà trouvé le bon chemin*)
let case_fantome_nonvariable = !case_fantome in
for i=0 to (List.length voisine.(case_fantome_nonvariable) - 1) do
    if (est_relie (List.nth voisine.(case_fantome_nonvariable) i) !case_pacman case_fantome_nonvariable voisine == true) && (!once == true) then
    begin
        trace_fantome (List.nth voisine.(case_fantome_nonvariable) i) case_fantome_nonvariable l h taille_case taille_case (taille_case*(h+1)) ; 
        case_fantome := List.nth voisine.(case_fantome_nonvariable) i;
        once := false;
    end;
done;;

let (c,d) = generate_lab l h;; (*c sera donc notre tableau mur_présent, d sera notre tableau voisine*)

trace_lab taille_case (taille_case*(h+1)) taille_case l h c;; (*on trace le labyrinthe*)

let trace_gagner() = (*On trace "Gagné" si le pacman a réussi à sortir*)
let taille = ((taille_case*taille_case*l*h) / 2500 ) in
let valeur = ("-*-fixed-medium-r-semicondensed--")^ string_of_int(taille)^("-*-*-*-*-*-iso8859-1") in
set_color red;
moveto (( (l+2)*taille_case) /2 - (taille*5)/4) (((h+2)*taille_case)/2 - (taille/2) );
set_font valeur;
draw_string ("GAGNE");;

let trace_perdu() = (*De même que pour trace_gagner, on trace "Perdu" si le fantôme attrape le pacman*)
let taille = ((taille_case*taille_case*l*h) / 2500 ) in
let valeur = ("-*-fixed-medium-r-semicondensed--")^ string_of_int(taille)^("-*-*-*-*-*-iso8859-1") in
set_color red;
moveto (( (l+2)*taille_case) /2 - (taille*5)/4) (((h+2)*taille_case)/2 - (taille/2) );
set_font valeur;
draw_string ("PERDU");;

let rec updatefantome()=  (*Boucle infinie qui permet la mise à jour du fantôme et qui est faite sur un différent thread*)
    Unix.sleep 2;
    if !end_game == true then (*Si le jeu est fini alors on arrête les mouvements du fantôme avec Thread.exit*)
    begin
    Thread.exit() ;
    end;
    fantome d;
    if !case_pacman == !case_fantome then 
        begin
            clear_graph();
            trace_perdu();
            end_game:=true;
        end;
    updatefantome()
;;

let _= Thread.create updatefantome();; (*Lance le thread du fantôme*)

let () =                                                                                        (*Lance la boucle infinie du pacman*)
    let fin = ref true in
    trace_pacman !case_pacman !case_pacman l h taille_case taille_case (taille_case*(h+1)) ; 
    trace_fantome !case_fantome !case_fantome l h taille_case taille_case (taille_case*(h+1)) ; 
    while !fin do
        pacman l h c taille_case taille_case (taille_case*(h+1));

        if !case_pacman==( l * h - 1) then              (*On teste la victoire du pacman*)
        begin 
        clear_graph();
        trace_gagner();
        fin := false;
        end_game := true;
        end;

        if !case_pacman == !case_fantome then           (*On teste la défaite du pacman*)
        begin
        clear_graph();
        trace_perdu();
        fin :=false;
        end_game := true;
        end;
    done;
;;

let ()=                          (*Permet de fermer la fenêtre après la fin de la partie en appuyant sur n'importe quel caractère sauf la barre espace*)
    let a=ref true in
    while !a do
    let cha = read_key() in
    if cha <> ' ' then a:=false;
    done;;