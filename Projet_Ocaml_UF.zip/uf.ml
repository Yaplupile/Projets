module Union_find = struct

    type t ={tab:int array;rang:int array }

    let create n = {tab=Array.init n (fun i ->i);rang=Array.init n (fun i ->0)};;

    let rec find uf n = 
        if uf.(n) <> n then begin uf.(n) <- find uf uf.(n) end;
        uf.(n);
    ;;

    let union uf n m =  
    if uf.rang.(n)>=uf.rang.(m) then
    begin
        uf.tab.(find uf.tab n ) <-  uf.tab.( find uf.tab m );
        uf.rang.(n) <- uf.rang.(n)+1;
    end;
    if uf.rang.(m)>uf.rang.(n) then
    begin
        uf.tab.(find uf.tab n ) <-  uf.tab.( find uf.tab m );
        uf.rang.(m) <- uf.rang.(m)+1
    end;;
end;;