#define TAILLE 103 /*nbr premier de preference */


typedef struct _listechar{
    char * val;
    struct _listechar *suivant;
}lstc_test;

typedef struct _symbole{

    char *nom;
    lstc_test *code;
    struct _symbole *suivant;
    /*char *type;
    int pointeur;
    int fonction;*/
    /*int structure;*/
    
}symbole_test;


symbole_test* tableauVariables[TAILLE];
symbole_test* tableauFonctions[TAILLE];


void print_s(symbole_test* s);

int hash(char *nom);

void table_reset(symbole_test ** table);

char * new_tmp();

symbole_test* rechercher(symbole_test* m,symbole_test** tableau);

int absent_table(symbole_test* m,symbole_test** tableau);

int inserer(symbole_test* element, symbole_test** tableau);

lstc_test *concat(lstc_test* liste1, lstc_test* liste2);

char* concat_chaine(char* a, char* b);

lstc_test *mini_concat(lstc_test* liste1, char * chr);

symbole_test* init_symbole(char* nom);

lstc_test *init_liste(char* val);

void affiche(symbole_test** table);

void affiche2(lstc_test* liste);

char* new_Else();

char* new_for();

char* new_test();

char* new_while();

char* new_leave();

int verif_type(char* a , char* b);