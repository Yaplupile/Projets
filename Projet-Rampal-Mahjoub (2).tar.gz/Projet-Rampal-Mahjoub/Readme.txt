Notre compilateur ne gère pas les structures.
L'analyse sémantique est mise en commentaire.


Pour compiler : 

- executer "make clean" en ligne de commande afin de supprimer l'essai précédent
                
- executer "make all" afin de compiler notre fichier dans un fichier "fichierbe" 
et de faire une vérification lexico-syntaxique dont le résultat sera affiché dans "verif_fichier_be"

ATTENTION : Si vous voulez changer le fichier à compiler, il faut directment changer
la ligne de commande dans le makefile du type :

    " ./$(PROG) <[fichier_à_compiler.c] > fichierbe "

La ligne de commande est initilisée sur le fichier "variables.c" de base