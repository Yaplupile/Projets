#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Table_de_Symboles.h"
# define TAILLE 103 /*nbr premier de preference */
int yyparse();
int compteur_temp=0;
int compteur_temp_test=0;
int compteur_temp_else=0;
int compteur_temp_for=0;
int compteur_temp_while=0;
int compteur_temp_leave=0;


void print_s(symbole_test* s){
    while(s!= NULL){
        printf("[%s]->", s->nom);
        s = s->suivant;
    }
    printf("NULL\n");
}

void print_symb(symbole_test* s){
    printf("nom : %s\n",s->nom);
}

void table_reset(symbole_test ** table){
    int i ;
    for(i = 0; i < TAILLE; i++){
        table[i] = NULL;
    }
}


int hash(char *nom){
    int i, r;
    int taille = strlen(nom);
    r = 0;
    for( i = 0; i < taille; i++)
        r = ((r << 8)+nom[i])%TAILLE;
    return r;
}


symbole_test* init_symbole(char* nom){
    symbole_test* a;
    a=(symbole_test *) malloc(sizeof(symbole_test));
    a->code=init_liste("");
    a->nom=strdup(nom);
    /*a->type="";
    a->pointeur=0;
    a->fonction=0;*/
    return a;
}


char* new_tmp(){
    char* a;
    size_t t=6;
    a=(char * )malloc(t);
    sprintf(a,"tmp%d",compteur_temp);
    compteur_temp++;
    return a;
}


char * concat_chaine(char * a , char * b){
    char * c;
    c=(char * )malloc(strlen(a)+strlen(b)+1);
    sprintf(c,"%s%s",a,b);
    return c;

}


void affiche2(lstc_test* liste){
    lstc_test* s;
    s=liste;
     while (s != NULL){
         printf("%s",s->val);
        s=s->suivant;
    }
}

lstc_test* concat(lstc_test* liste1, lstc_test* liste2){
    lstc_test* s;
    s=liste1;
    if (liste1!=NULL){
        while (s->suivant != NULL){
            s=s->suivant;
        }
        s->suivant=liste2;
    }
    return liste1;
}

lstc_test* mini_concat(lstc_test* liste1, char * chr){
    lstc_test* s;
    lstc_test* x;
    s=liste1;
    if (liste1!=NULL){
        while (s->suivant != NULL){
            s=s->suivant;
        }
        s->suivant=(lstc_test *) malloc(sizeof(lstc_test));
        x=s->suivant;
        x->val=strdup(chr);
        x->suivant=NULL;
        
    }
    return liste1;
}

lstc_test *init_liste(char* val){
     lstc_test* liste1=malloc(sizeof(lstc_test));
     liste1->val=strdup(val);
     liste1->suivant=NULL;
     return liste1;
}

int verif_type(char* a , char* b){
        if ((strcmp(a,"int")==0) && (strcmp(b,"int")==0)){
                return 1;
        }
        return 0;
}


int inserer( symbole_test* element, symbole_test** tableau) {
    int h;
    symbole_test *s;
    symbole_test *precedent;
    h = hash(element->nom);
    s = tableau[h];
    precedent = NULL;
    while ( s != NULL ) {
        if ( strcmp( s->nom, element->nom ) == 0 ){ return -1; }
        precedent = s;
        s = s->suivant;
        }
    if ( precedent == NULL ) {
        tableau[h] = (symbole_test *) malloc(sizeof(symbole_test));
        s = tableau[h];
    }
    else {
        precedent->suivant = (symbole_test *) malloc(sizeof(symbole_test));
        s = precedent->suivant;
    }
    s->nom = strdup(element->nom);
    s->suivant = NULL;
    return 1;
}

symbole_test* rechercher(symbole_test* m,symbole_test** tableau){
    symbole_test *q;
    for (int i = 0; i < TAILLE; i++){
        q=tableau[i];
        while (q!=NULL){
            if (strcmp(q->nom,m->nom)==0){
                return q;
            }
            q=q->suivant;
        }
    }
    return NULL;
}

int absent_table(symbole_test* m,symbole_test** tableau){
    symbole_test *q;
    for (int i = 0; i < TAILLE; i++){
        q=tableau[i];
        while (q!=NULL){
            if (strcmp(q->nom,m->nom)==0){
                return 0;
            }
            q=q->suivant;
        }
    }
    return 1;
}

void affiche(symbole_test **table){
    int i;
    symbole_test* s;
    for(i = 0; i < TAILLE; i++){
        if(table[i]==NULL){
            printf("table[%d]->NULL\n", i);
        }
        else{
            s = table[i];
            printf("table[%d]-> %s ", i, s->nom);
            while(s!= NULL){
                printf("[%s]->", s->nom);
                s = s->suivant;
            }
            printf("NULL\n");
        }
    }
}

char* new_Else(){
    char* a;
    size_t t=7;
    a=(char * )malloc(t);
    sprintf(a,"Lelse%d",compteur_temp_else);
    compteur_temp_else++;
    return a;
}

char* new_test(){
    char* a;
    size_t t=7;
    a=(char * )malloc(t);
    sprintf(a,"Ltest%d",compteur_temp_test);
    compteur_temp_test++;
    return a;
}

char* new_for(){
    char* a;
    size_t t=7;
    a=(char * )malloc(t);
    sprintf(a,"Lfor%d",compteur_temp_for);
    compteur_temp_for++;
    return a;
}

char* new_while(){
    char* a;
    size_t t=7;
    a=(char * )malloc(t);
    sprintf(a,"Lwhile%d",compteur_temp_while);
    compteur_temp_while++;
    return a;
}

char* new_leave(){
    char* a;
    size_t t=7;
    a=(char * )malloc(t);
    sprintf(a,"Lleave%d",compteur_temp_leave);
    compteur_temp_leave++;
    return a;
}


int main(){
    yyparse();
    return(0);
}
